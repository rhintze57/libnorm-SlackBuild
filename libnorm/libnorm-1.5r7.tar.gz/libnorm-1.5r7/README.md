#### Build instructions
  1. cd norm
  1. ./waf --configure
  1. ./waf
  1. cd makefiles
  1. make -f Makefile.linux
